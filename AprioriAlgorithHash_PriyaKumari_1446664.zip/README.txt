----------------------------------------------------------------------------------------------
STEPS TO COMPILE AND EXECUTE APPLICATION
----------------------------------------------------------------------------------------------

1) Open the .SLN file (i.e. Microsoft Visual Studio Solution) present in the root folder using Visual Studio any version above 2008
2) Once application is open go to 'Build' menu option >> 'Rebuild Solution' option and click 'Rebuild Solution' to compile the code
3) In Order to Execute
	a) Execute from Visual Studio -> Go to 'Debug' menu option >> 'Start without Debugging' and select that option to launch application
	b) Execute from deployable executable -> Go to solution root folder > Select project folder > Go to bin folder> Select either debug or release version of executable > double click the executable to launch the application


For application screenshot refer "Application Design and Screenshot.doc"
---------------------------------------------------------------------------------------------------


