﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace AprioriAlgorithHash_PriyaKumari_1446664
{
    public class HashMap
    {
        public string UniqueString { get; set; }
        public int Order { get; set; }
        public int Count { get; set; }
        public List<int> TransactionId {get;set;}
    }
}
