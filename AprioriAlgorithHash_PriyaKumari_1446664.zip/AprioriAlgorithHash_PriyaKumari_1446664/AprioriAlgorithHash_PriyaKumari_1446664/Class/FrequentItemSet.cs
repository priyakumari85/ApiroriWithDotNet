﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace AprioriAlgorithHash_PriyaKumari_1446664.Class
{
    public class FrequentItemSet
    {
        public List<int> Values { get; set; }
        public List<int> TransactionID { get; set; }
        public int Count { get; set; }
    }
}
